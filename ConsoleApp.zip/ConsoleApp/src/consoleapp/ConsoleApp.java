/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consoleapp;

/**
 *
 * @author Mthunzi
 */
public class ConsoleApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int [] Numbers = new int [8];
        for(int i = 0; i<Numbers.length; i++)
        {
            Numbers[i] = (int)(Math.random()*100+1);
        }
    mSort(Numbers);
    }
   
    public static void mSort(int [] arr)
    {
        int temp;
        for (int i = arr.length-1; i>0; i--)
        {
            for (int a = 0; a < i; a++)
            {
                if (arr[a]>arr[a+1])
                {
                    temp = arr[a];
                    arr[a] = arr[a+1];
                    arr[a+1] = temp;
                }
            }
        }
        for (int i = 0; i<arr.length;i++)
        {
            System.out.print(arr[i]+ ", ");
        }
        System.out.println();
    }


    
    }