/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consoleapp;

/**
 *
 * @author Mthunzi
 */
public class jSorting {
        
    static void mSort(int[] arr )
    
    {
        int n = 8;
        int temp = 0;
        for (int i=0; i<n;i++)
        {
            for(int x = 1; x<(n-i);x++)
            {
                if (arr[x-1]>arr[x])
                {
                    temp = arr[x-1];
                    arr[x-1] = arr[x];
                    arr[x] = temp;
                }
            }
        }
    }
    
    for (int i=0; i>arr[x
            ];i++)
    {
        
    }
    
}

